# Frost Bot Studio — standalone dashboard preview

This is a frontend-only Discord bot dashboard concept. It is intentionally not connected to any bot or Discord API yet. Bot profiles, server selection, command settings, and activity are local demo data stored in the page runtime and reset on refresh.

## Open

Open `index.html` in a modern browser. No build tools or backend are required.

## Future integration design

The UI is organized around a replaceable API adapter. A future backend can implement these authenticated endpoints:

- `GET /api/v1/health` — backend and bot health
- `GET /api/v1/bots` — bot profiles visible to the signed-in dashboard user
- `POST /api/v1/bots` — register a bot profile (never accept bot tokens from browser storage)
- `PATCH /api/v1/bots/:id` — update display name and configuration
- `GET /api/v1/servers` — Discord guilds available to the signed-in user
- `GET /api/v1/bots/:id/servers` — server assignments
- `PUT /api/v1/bots/:id/servers/:guildId` — assign a bot to a guild
- `GET /api/v1/activity` — audit activity
- `GET/PUT /api/v1/servers/:guildId/settings` — server settings

Recommended future architecture:

1. React/vanilla frontend calls your own HTTPS backend only.
2. Backend authenticates dashboard users with secure sessions (HttpOnly, Secure, SameSite cookies) and Discord OAuth2.
3. Backend stores bot tokens in environment secrets or a secret manager. Never put tokens in frontend JavaScript, localStorage, or browser-visible API responses.
4. Bot worker communicates with the backend through authenticated internal APIs or a message queue.
5. Enforce per-guild permissions and audit every configuration change.
6. Keep all bot-specific command handlers and business logic in the existing bot project; connect them through a thin adapter rather than rewriting them.

## Current status

- Dashboard navigation and responsive layout: implemented.
- Add/remove bot display profiles: local demo only.
- Server selector: local demo only.
- Command Studio, Embed Studio, Moderation, Welcome & Roles, Ticket Panels, Scheduler, Audit Logs, Integrations, Settings: UI previews.
- Real Discord OAuth, bot token management, live bot status, and persistent storage: not implemented.

This package is a separate safe frontend prototype. It does not contain or modify the uploaded bot backend.
